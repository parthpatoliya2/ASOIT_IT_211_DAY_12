<?php
   if(isset($_POST["submit"]))
   {
    if(isset($_POST["firstname"])&& isset($_POST["lastname"]) && isset($_POST["date"]) && isset($_POST["conno"])&& isset($_POST["gen"]) && isset($_POST["email"])
&& isset($_POST["password"]) && isset($_POST["address"]) && isset($_POST["chek"]))  
  {
        $firstname=$_POST["firstname"];
        $lastname=$_POST["lastname"];
        $date=$_POST["date"];
        $conno=$_POST["conno"];
        $gen=$_POST["gen"];
        $email=$_POST["email"];
        $password=$_POST["password"];
        $address=$_POST["address"];
        $chek=$_POST["chek"];
    }
   }
   echo "firstname" $firstname;
   echo "<br>";
   echo $lastname;
   echo "<br>";
   echo $date;
   echo "<br>";
   echo $conno;
   echo "<br>";
   echo $gen;
   echo "<br>";
   echo $email;
   echo "<br>";
   echo $password;
   echo "<br>";
   echo $address;
   echo "<br>";
   echo $chek; 
   echo "<br>";
   ?>